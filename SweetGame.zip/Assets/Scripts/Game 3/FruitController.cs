using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class FruitController : MonoBehaviour
{
    private Image _image;

    private Animator _animator;

    [HideInInspector]
    public UnityEvent FruitIsCatch;

    private bool _isCatch = false;

    private float _activeTime = 1.3f;

    private void Awake()
    {
        FruitIsCatch = new UnityEvent();
        _image = GetComponent<Image>();
        _animator = GetComponent<Animator>();
    }

    public void ActiveFruit(Sprite img)
    {
        if (!_isCatch)
        {
            _animator.SetBool("Reduce", false);
            _animator.SetBool("Expand", true);
            _isCatch = true;
            _image.sprite = img;
            StartCoroutine(FruitCoroutine());
        }
    }

    private IEnumerator FruitCoroutine()
    {
        while (_isCatch)
        {


            yield return new WaitForSeconds(_activeTime);

            _isCatch = false;
            _animator.SetBool("Reduce", true);
            _animator.SetBool("Expand", false);
        }

    }

    public void FruitCatch()
    {
        Debug.Log("Press!");

        if (_isCatch)
        {
            _animator.SetBool("Reduce", true);
            _animator.SetBool("Expand", false);
            _isCatch = false;
            FruitIsCatch.Invoke();
        }
    }

    private void OnDestroy()
    {
        FruitIsCatch.RemoveAllListeners();
    }
}
